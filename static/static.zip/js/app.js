String.prototype.getBaseConversionNumber = getBaseConversionNumber
String.prototype.CvnFromTo = CvnFromTo;
String.prototype.convertDigits = convertDigits;
let a=[];
let trigAdd = false;
let trigEdit = false;		 
let trigDel = false;		 
let trigDellAll = false;	
let loader = `<div id="loadr" class="lds-dual-ring"></div>`;
let cnt = 0;
var today = Date.now();
const todayFa = {
	"day": getDateFormat(today, {"day": "2-digit"}),
	"month": getDateFormat(today, {"month": "numeric"}),
	"monthTitle": getDateFormat(today, {"month": "long"}),
	"mainyear": getDateFormat(today, {"year": "numeric"}),
	"year": String(jyear, {"year": "numeric"}),
	"dayWeek": getDateFormat(today, {"weekday": "long"}),
}
// index month to label
const monthLabel = ["jalali","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند",];
const M_months = ["miladi","January","February","March","April","May","June","July","August","September","October","November","December"];
const H_months = ["hijri","محرم","صفر","ربيع الاول","ربيع الثاني","جمادي الاول","جمادي الثاني","رجب","شعبان","رمضان","شوال","ذوالقعده","ذوالحجه"];
//calendarObject.js
//استایل فصل ها
const cssProperty = {
    "spring": [
        {
            selector: ".num-dates ul li:hover, .num-dates ul li:hover",
            property: [
                "background-color: #5e991a;",
                "color: white;",
            ]
        },

        {
            selector: ".active-season",
            property: [
                "background-color: #5e991a !important;",
                "color:white !important;",
            ]
        },

        {
            selector: ".active-season-cr, .month-hover:hover",
            property: [
                "color: #5e991a !important;"
            ]
        },

        {
            selector: ".holiday:hover, .active-season-bg",
            property: [
                "background-color: #5e991a !important;",
            ]
        },

        {
            selector: ".year-meta, .year",
            property: [
                "color: #5e991a;",
            ]
        }
    ],

    "summer": [
        {
            selector: ".num-dates ul li:hover, .num-dates ul li:hover",
            property: [
                "background-color: #4caf50 ;",
                "color: white;",
            ]
        },

        {
            selector: ".active-season",
            property: [
                "background-color: #4caf50  !important;",
                "color:white !important;",
            ]
        },

        {
            selector: ".active-season-cr, .month-hover:hover",
            property: [
                "color: #4caf50  !important;"
            ]
        },

        {
            selector: ".holiday:hover, .active-season-bg",
            property: [
                "background-color: #4caf50  !important;",
            ]
        },

        {
            selector: ".year-meta, .year",
            property: [
                "color: #4caf50 ;",
            ]
        }
    ],

    "fall": [
        {
            selector: ".num-dates ul li:hover, .num-dates ul li:hover",
            property: [
                "background-color: #ff9800;",
                "color: white;",
            ]
        },

        {
            selector: ".active-season",
            property: [
                "background-color: #ff9800 !important;",
                "color:white !important;",
            ]
        },

        {
            selector: ".active-season-cr, .month-hover:hover",
            property: [
                "color: #ff9800 !important;"
            ]
        },

        {
            selector: ".holiday:hover, .active-season-bg",
            property: [
                "background-color: #ff9800 !important;",
            ]
        },

        {
            selector: ".year-meta, .year",
            property: [
                "color: #ff9800;",
            ]
        }
    ],

    "winter": [
        {
            selector: ".num-dates ul li:hover, .num-dates ul li:hover",
            property: [
                "background-color: #0984e3;",
                "color: white;",
            ]
        },

        {
            selector: ".active-season",
            property: [
                "background-color: #0984e3 !important;",
                "color:white !important;",
            ]
        },

        {
            selector: ".active-season-cr, .month-hover:hover",
            property: [
                "color: #0984e3 !important;"
            ]
        },

        {
            selector: ".holiday:hover, .active-season-bg",
            property: [
                "background-color: #0984e3 !important;",
            ]
        },

        {
            selector: ".year-meta, .year",
            property: [
                "color: #0984e3;",
            ]
        }
    ]
};

const metaYear = {
    year: todayFa['year'].convertDigits("fa"),
    metaYear: metanames,
}

const headDOM = document.getElementsByTagName("head")[0];

const parentDateDOM = document.getElementsByClassName('num-dates')[0];
const parentMetaYearDOM = document.getElementsByClassName('year-wrapper')[0];
const parentEventsDOM = document.getElementsByClassName('calendar-left')[0];

const todayDateDOM = document.getElementsByClassName("num-date")[0];
const todayDayDOM = document.getElementsByClassName("day")[0];

// set Property
todayDateDOM.textContent = todayFa['day'].convertDigits("fa");
todayDayDOM.textContent = todayFa['dayWeek'].convertDigits("fa");
//click out of modal
window.onclick = function(e){
	const main = document.getElementById('main');
	const modal = document.getElementById('modal');
	const light_m = document.getElementById('light_mode');
	theme = document.documentElement.getAttribute('data-bs-theme');
	if (main === e.target) {
		modal.classList.remove('is-open');
		main.classList.remove('modal-is-open');
	}
	else if (e.target === light_m){
		(theme == 'dark') ? document.documentElement.setAttribute('data-bs-theme','light')
						  : document.documentElement.setAttribute('data-bs-theme','dark');
		}
	}
// event listener
const monthLetter = document.getElementsByClassName("month-letter");
for (const element of monthLetter) {
	element.onclick = function (e) {
		const thisElement = e.target;
		if (thisElement.classList.contains("active-season-cr")) return;
		
		const monthDataNumber = thisElement.getAttribute("data-num");
		activeMonthElement('dynamic-element', `dynamic-element-${monthDataNumber}`, 'active-element');
		activeMonthElement('month-letter', `month-letter-${monthDataNumber}`, 'active-season-cr');
	}
}

let season = getSeasonByMonNum(todayFa.month);
let cssSeason = getCssBySeason(season);

let styleCustom = document.getElementById("style-cln");

if (!styleCustom)
	headDOM.innerHTML += `<style id="style-cln">${cssSeason}</style>`;
else {
	styleCustom.innerHTML = cssSeason;
}

let monthCounter = 1;
for (const month of calendarObject) {
	cnt=0;
	const dateList = [];
	let liCounter = 0;
	let UlCounter = 1;
	let oneStarted = false;
	let tmpMetaYear = metaYear.metaYear[monthCounter - 1];
	tmpMetaYear = tmpMetaYear.split(" | ");
	parentMetaYearDOM.innerHTML += generateTemplateHTML("metaYear", {
		index: monthCounter,
		year: metaYear.year,
		arabic: tmpMetaYear[1],
		miladi: tmpMetaYear[0],
	});
	for (const day of month) {
		cnt++;
		const currentMonth = monthLabel[monthCounter];

		if (day[5])
			oneStarted = false;
		else {
			oneStarted = true;
			dateList.push(day[0]);
		}
		var ulCurrentClass = `wk-${monthCounter}-${UlCounter}`;

		if (liCounter == 7) {
			document.getElementsByClassName(ulCurrentClass)[0].innerHTML += "<div class=\"clearfix\"></div>";
			liCounter = 0;
			UlCounter++;
		}

		ulCurrentClass = `wk-${monthCounter}-${UlCounter}`;

		var ulCurrent = document.getElementsByClassName(ulCurrentClass)[0];

		if (!ulCurrent) {
			var htmlUL = '';
			htmlUL += `<ul class="week ${ulCurrentClass} month-${monthCounter} dynamic-element dynamic-element-${monthCounter}"></ul>`;
			parentDateDOM.innerHTML += htmlUL;
			ulCurrent = document.getElementsByClassName(ulCurrentClass)[0];
		}
		let liClass = "day-element ";
		let liClick = "";
		if (!oneStarted)
			liClass += "disable-one ";
		else if (oneStarted)
			liClass += `date-${monthCounter}-${day[0].convertDigits("en")} `;
		if (day[3] === true)
			liClass += "holiday ";
		//----------------------------------
		bdg='';
		if ( day[6].length > 0) 
			bdg = `<small class="bdgs"></small>`;
		
		liClick = `onclick= "handleModal(${monthCounter},${day[0].convertDigits("en")});"`;
		//----------------------------------
		ulCurrent.innerHTML += generateTemplateHTML('date', {
			class: liClass,
			bdg : bdg,
			jalali: day[0].toString().convertDigits("fa"),
			click: liClick,
			miladi: day[1],
			ghamari: day[2].toString().convertDigits("ar"),
		});

		const eventClass = `event-list-${monthCounter}`;
		let eventDOM = document.getElementsByClassName(eventClass)[0];
		if (!eventDOM) {
			parentEventsDOM.innerHTML += `<ul class="custom-scrollbar-container events-list event-list-${monthCounter} dynamic-element dynamic-element-${monthCounter} "></ul>`;
			eventDOM = document.getElementsByClassName(eventClass)[0];
		}
		for (const dayElement of day[4]) {
			const indexBracket = dayElement.indexOf("[");
			const eventdate = (0 <= indexBracket) ? dayElement.substring(indexBracket) : "";
			
			const eventTitle = dayElement.replace(eventdate, "");
			const startedDate = dateList[dateList.length - 1];
			
			if (oneStarted) {
				eventDOM.innerHTML += generateTemplateHTML('events', {
					day: `${startedDate} ${currentMonth}`.convertDigits("fa"),
					eventTitle: eventTitle,
					date: eventdate,
				});
			}
		}
		liCounter++;
	} //end for (const day of month);
	monthCounter++;
} //end for (const month of calendarObject);
activeMonthElement('dynamic-element', `dynamic-element-${todayFa.month}`, 'active-element');
activeMonthElement('month-letter', `month-letter-${todayFa.month}`, 'active-season-cr');
activeMonthElement('day-element', `date-${todayFa.month}-${parseInt(todayFa.day)}`, 'active-season');
function getSeasonByMonNum(numMonth) {
	const monthSeason = [
		"spring",
		"summer",
		"fall",
		"winter",
	];

	let season = "";

	if (numMonth <= 3) {
		season = monthSeason[0];
	} else if (3 < numMonth && numMonth <= 6) {
		season = monthSeason[1];
	} else if (6 < numMonth && numMonth <= 9) {
		season = monthSeason[2];
	} else if (9 < numMonth && numMonth <= 12) {
		season = monthSeason[3];
	}
	return season;
}

function getCssBySeason(season) {
	const cssObjects = cssProperty[season];
	let cssString = "";
	for (const cssObject of cssObjects) {
		let template = `${cssObject['selector']}{\n`;
		for (const property of cssObject['property']) {
			template += `${property}\n`;
		}
		template += "}\n\n"
		cssString += template;
	}
	return cssString;
}

function getDateFormat(uDate, option) {
	let date = new Intl.DateTimeFormat('fa-IR', option).format(uDate);
	date = date.convertDigits("en");
	return date;
}

function activeMonthElement(allCls, whichCls, activeCls) {
	const dynamicElement = document.getElementsByClassName(allCls);
	for (const element of dynamicElement) {
		if (element.classList.contains(activeCls))
			element.classList.remove(activeCls);
		else if (element.classList.contains(whichCls))
			element.classList.add(activeCls);
	}
}

function generateTemplateHTML(type, data) {
	let htmlTemplate = '';	
	if ( String(data.class).includes('disable') ) 
		data.click = '';
	if (type == "date") {
		if (data.class.includes('disable-one')) {
			htmlTemplate = `<li  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="" class="${data.class}"` + data.click + `index="${cnt}"><span  id="jalali" data_m="${mDays[monthCounter]['miladi'][data.jalali.convertDigits('en')]}"data_h="${mDays[monthCounter]['hijri'][8]}">${data.jalali}</span><small id="miladi">${data.miladi}</small><small id="ghamari">${data.ghamari}</small>${data.bdg}`;
		} else {
			tmp = parseInt(data.jalali.convertDigits('en'));
			m_date = ((mDays[monthCounter]['miladi'][tmp]).split('-')); //m-d-y
			h_date = (mDays[monthCounter]['hijri'][tmp].split('-')); //m-d-y
			m_date[0] = parseInt(m_date[0],10);
			h_date[0] = parseInt(h_date[0],10);
			m_dateLabel = M_months[m_date[0]];
			h_dateLabel = H_months[h_date[0]];
			htmlTemplate = `<li  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="${h_dateLabel + ' - ' + m_dateLabel}" class="${data.class}"`+ data.click + `index="${cnt}"><span  id="jalali" data_m="${mDays[monthCounter]['miladi'][data.jalali.convertDigits('en')]}"data_h="${mDays[monthCounter]['hijri'][8]}">${data.jalali}</span><small id="miladi">${data.miladi}</small><small id="ghamari">${data.ghamari}</small>${data.bdg}`;
		}
	}else if (type == "metaYear") {
		//htmlTemplate = `<select class="year yr-${data.index} dynamic-element dynamic-element-${monthCounter}" onchange='selectYear(this)'>${yearList.convertDigits('fa')}</select> <div class="year-meta myr-${data.index} dynamic-element dynamic-element-${monthCounter}">${data.arabic}<br>${data.miladi}</div>`;
		htmlTemplate = `<div class="year yr-${data.index} dynamic-element dynamic-element-${monthCounter}">${data.year}</div> <div class="year-meta myr-${data.index} dynamic-element dynamic-element-${monthCounter}">${data.arabic}<br>${data.miladi}</div>`;
	} else if (type == "events") {
		htmlTemplate = `<li><span class="event-day">${data.day} </span><div class="event-title">${data.eventTitle}</div><span class="event-date-type"> ${data.date}</span></li>`;
	}
	return htmlTemplate;
}

function convertDigits(to) {
	let str = this;
	const toCvn = (this.getBaseConversionNumber(to))[to];
	const allDigits = this.getBaseConversionNumber("all");

	delete allDigits[to];

	const Objkeys = Object.keys(allDigits);
	for (var i = 0; i < Objkeys.length; i++) {
		const currentKey = Objkeys[i];
		const fromCvn = allDigits[currentKey];
		str = this.CvnFromTo(fromCvn, toCvn, str)
	}
	return str;
}

function CvnFromTo(fromDigits, toDigits, str) {
	var str = str == undefined ? this : str;
	for (var i = 0; i < toDigits.length; i++) {
		const currentFromDigit = fromDigits[i];
		const currentToDigit = toDigits[i];
		const regex = new RegExp(currentFromDigit, 'g');
		str = str.replace(regex, currentToDigit);
	}
	return str;
}

function getBaseConversionNumber(label) {
	const faDigits = ['۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '۰'];
	const enDigits = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
	const arDigits = ['١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٠'];

	var whichDigit = {};

	switch (label) {
		case 'fa':
			whichDigit[label] = faDigits;
			break;
		case 'en':
			whichDigit[label] = enDigits;
			break;
		case 'ar':
			whichDigit[label] = arDigits;
			break;
		case 'all':
			whichDigit = {
				"fa": faDigits,
				"en": enDigits,
				"ar": arDigits
			};
			break;
		default:
			whichDigit = [];
	}

	return whichDigit;
}

/*************************************************** */
function newEvent(e,mnth,dys) {
	document.getElementById('modalfoot').classList.remove('display-none');
	e.classList.add('display-none');
	btn = document.getElementsByClassName('addevent');
	btn[0].setAttribute('onclick','handleAdd(' + mnth + ',' + dys + ',"n")');
}

function resetForm() {
	document.getElementById('modalfoot').classList.add('display-none');
	document.getElementById('task-form').reset();
	document.getElementById('task-isfixed').checked=false ;
	document.getElementById('task-title').value = '';
	document.getElementById('task-text').value = '';
	document.getElementById('task-isfixed').checked = false;
	document.getElementById('task-repeat').selectedIndex = 2;
	document.getElementsByClassName('newevent')[0].classList.remove('display-none');
}

function handleModal(m,d) {
	const main = document.getElementById('main');
	const modal = document.getElementById('modal');
	months = Number(m);
	days = Number(d);
	modal.classList.add('is-open'); 
	main.classList.add('modal-is-open');
	m2 = document.getElementsByClassName('active-season-cr');
	let liClassE = '';
	let html = '';
	//نام ماه های میلادی و قمری
	m_date = ((mDays[m]['miladi'][d]).split('-')); //m-d-y
	h_date = (mDays[m]['hijri'][d].split('-')); //m-d-y
	m_date[0] = parseInt(m_date[0],10);
	h_date[0] = parseInt(h_date[0],10);
	m_dateLabel = M_months[m_date[0]];
	h_dateLabel = H_months[h_date[0]];
	html += `<div class="modalHead active-season">
			<button type="button" class="btn-close btn-sm close" onClick="handleModalClose()" data-bs-dismiss="modal" aria-label="Close"></button>
			<ul class="list-inline pe-0 text-center">
				<li class="list-inline-item font-monospace text-white-50">${m_date[2]} ${m_dateLabel} ${m_date[1]}</li> -
				<li class="list-inline-item fs-4 fw-bold text-white">${String(days).convertDigits('fa')}  ${m2[0].innerText} ${String(metaYear.year)}</li> -
				<li class="list-inline-item text-white-50">${h_date[1].convertDigits('fa')} ${h_dateLabel} ${h_date[2].convertDigits('fa')}</li> 
			</ul>
			<div class="footer ">
			<button class="clear-all text-white" onclick="handleDelAll(${months},${days});">حذف همه</button>
			<div style="margin: auto;"> شما <span class="task-count">${liClassE.length}</span> رویداد برای امروز ثبت کرده اید</div>
			</div>
			</div>`;	
	html +=`<div class="modalMain" id="modalMain">
		</div>`;
	html +=`<button type="button" class="add-btn newevent text-white" onclick="newEvent(this,${months},${days});">${svg_new}</button>
		<div class="modalFoot active-season display-none" id="modalfoot" >
			<div class="form-container">
				<form class="task-form d-block" id="task-form" >
				<div class="task-input1">
					<input type="text" class="task-input" name="1"  id="task-title" placeholder="عنوان رویداد مورد نظر ....." />
					<span>تکرار</span>
					<select id="task-repeat" class="task-input" name="2">
						<option class="" value="0">روزانه</option>
						<option class="" value="1">ماهانه</option>
						<option class="" value="2">سالانه</option>
					</select>
					<span >هشدار</span><input type="checkbox" id="task-isfixed" class="task-checkbox">
				</div>
				<div class="task-input1 d-flex ">
					<textarea  class="task-input txtarea"  id="task-text" name="4" placeholder="توضیحات رویداد مورد نظر ....." ></textarea>
					<button type="button" class="add-btn addevent text-white " onclick="handleAdd(${months},${days},'n');">${svg_confirm}</button>
					<button type="button" class="add-btn text-white btn-danger" onclick="resetForm();">${svg_cancel}</button>
				</div>
				</form>
			</div>
		</div>
		`;
	modal.innerHTML=html;
	
	openEmptyModal(months);
	
	dayindex = document.getElementsByClassName(`date-${months}-${days}`)[0].getAttribute('index');
	liClassE = calendarObject[months-1][dayindex-1][6];
	document.getElementById('tasksItems').innerHTML = handleTaskLists(liClassE,months,days);
}

function openEmptyModal (months) {
	const modalMain = document.getElementById("modalMain");
	const tUl = document.createElement('ul');
	const tTable = document.createElement('table');
	const tTbody = document.createElement('tbody');

	tUl.classList.add(`events-list`,`event-list-${months}`,`dynamic-element`,`dynamic-element-${months}`,`active-element`,`custom-scrollbar-container`);
	tTbody.setAttribute('id', 'tasksItems');
	tTable.appendChild(tTbody);
	tUl.appendChild(tTable);
	
	modalMain.appendChild(tUl);
}

function handleTaskLists(data,months,days) {
	let html = ``;
	let x = ``;
	  for (j = 0; j <= data.length - 1; j++) {
		let lst = data[j].split(':');
		x = lst[2];
		html += `<tr id="itm-${x}" class="itm-${x}" >
					<td class="td_task align-baseline ">
						<form class="task-form" id="task-form">
							<div class="dropdown delete-btn-dropdown">
								<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
									${svg_menu}
								</button>
								<ul class="dropdown-menu justify-content-center">
									<li class="border-0 shadow-none"><a class="delete-btn btn btn-sm btn-outline-danger" onClick="handleDelete(${months},${days},'${x}');">${svg_delete}</a></li>
									<li class="border-0 shadow-none"><a class="delete-btn btn btn-sm btn-outline-warning" onClick="handleEdit(${months},${days},'${x}');">${svg_edit}</a></li>
								</ul>
							</div>
						</form>
					</td>
					<td class="td_task2" onClick="showText('${x}')"><li ><span class="event-day" >${lst[0]}</span><em class="display-none " >${lst[1]}</em></li></td>
					 <input type="hidden" value=${lst[3]} data="${lst[4]}" />
				</tr>`;
	}
	document.getElementsByClassName('task-count')[0].innerText = String(j).convertDigits('fa');
 return html;
}

function handleModalClose() {
  const modal = document.getElementById('modal');
  const main = document.getElementById('main');
  modal.classList.remove('is-open');
  main.classList.remove('modal-is-open');
  modal.innerHTML = '';
}

function handleAdd(mm,dd,type) {
	const modal = document.getElementById('tasksItems');
	const title = document.getElementById('task-title');
	const text = document.getElementById('task-text');
	const fixed = document.getElementById('task-isfixed');
	const repeat = document.getElementById('task-repeat');
	const addevent = document.getElementsByClassName('addevent')[0];
	const counter = document.getElementsByClassName('task-count')[0];
	months = mm;
	days = dd;
	const dayindex = document.getElementsByClassName(`date-${months}-${days}`)[0].getAttribute('index');
	let elcounter = document.getElementsByClassName(`date-${months}-${days}`)[0].children.length;
	let html = ``;
	if (type === 'n') {
		if((title.value != '') && (trigAdd != true)) {
			trigAdd = true;
			addevent.innerText = '' ;
			addevent.insertAdjacentHTML('beforeend', loader);
			addevent.disabled = true;
			cnt=parseInt(counter.innerText.convertDigits('en')) + 1;
			const payload = {
			month : months,
			day : days,
			title : String(title.value),
			text : String(text.value),
			fixed : fixed.checked,
			repeat : repeat.value,
			year : jyear,
			};
			fetch(`${domain}addevents.php`, {
				method : 'POST',
				headers : {"Content-Type" : "application/json"},
				body : JSON.stringify(payload)
			})
			.then(res => {if (!res.ok) throw new Error('خطای سمت سرور'); return res.json();})
			.then(data => {
				document.getElementById('modalfoot').classList.add('display-none');
				document.getElementsByClassName('newevent')[0].classList.remove('display-none');
				chk = (fixed.checked == false) ? 0 : 1;
				calendarObject[months-1][dayindex-1][6].unshift(`${payload.title}:${payload.text}:${data.id}:${repeat.value}:${chk}`);
				html = handleTaskLists(Array (`${payload.title}:${payload.text}:${data.id}:${repeat.value}:${chk}`), months, days);
				modal.insertAdjacentHTML('afterbegin', html);
				if (elcounter <= 3)
					document.getElementsByClassName(`date-${months}-${days}`)[0].insertAdjacentHTML('beforeend','<small class="bdgs"></small>');
				resetForm();
				trigAdd = false;
				counter.innerText = String(cnt).convertDigits('fa');
				addevent.innerHTML = `${svg_confirm}`;
				addevent.disabled = false;
			})
			.catch(err => {
				alert('خطا');
				addevent.innerHTML = `${svg_confirm}`;
				addevent.disabled = false;
				console.error("خطا", err);
				trigAdd = false;
			})
		}

	} else {
		if ((title.value != '') && (trigEdit != true)) {
			if (window.confirm('آیااز تغییر مطمئن هستید؟') == true) {
			trigEdit = true;
			addevent.innerText = '' ;
			addevent.innerHTML = loader;
			addevent.disabled = true;
			const payload = {
				month : months,
				day : days,
				title : String(title.value),
				text : String(text.value),
				fixed : fixed.checked,
				repeat : repeat.value,
				id : type
				};
			fetch(`${domain}changeevents.php`, {
				method : 'POST',
				headers : {"Content-Type" : "application/json"},
				body : JSON.stringify(payload)
			})
			.then(res => { if (!res.ok) throw new Error('nooooooooooooo'); return res.text();})
			.then(data => {
				document.getElementById('modalfoot').classList.add('display-none');
				document.getElementsByClassName('newevent')[0].classList.remove('display-none');
				fix = document.getElementById(`itm-${type}`).querySelector('input');

				spanEle = document.getElementById(`itm-${payload.id}`).querySelector('span');
				emEle = document.getElementById(`itm-${payload.id}`).querySelector('em');

				spanEle.innerText = String(title.value);
				emEle.innerText = String(text.value);
				var i = 0;
				len = calendarObject[months-1][dayindex-1][6].length;
				for(i = 0; i< len; i++) {
					temp = calendarObject[months-1][dayindex-1][6][i].split(':');
					if (temp[2] == type) {
						temp[0] = String(title.value) ;
						temp[1] = String(text.value);
						temp[3] = repeat.value;
						temp[4] = Number(fixed.checked);
						ii = i;
						i = len;
					}
				}
				calendarObject[months-1][dayindex-1][6][ii] = `${temp[0]}:${temp[1]}:${temp[2]}:${temp[3]}:${temp[4]}`;
				fix.value = temp[3];
				fix.setAttribute('data', temp[4]);
				resetForm();
				trigEdit = false;
				addevent.innerHTML = `${svg_confirm}` ;
				addevent.disabled = false;
				})
				.catch(err => {
					addevent.innerHTML = `${svg_confirm}`;
					addevent.disabled = false;
					trigEdit = false;
					alert ( err);
				})
			}
		}
	}
	return 0;
}

function handleEdit(months,days,id) {
	document.getElementById('modalfoot').classList.remove('display-none');
	element = document.getElementById(`itm-${id}`).querySelector('span');
	detail = document.getElementById(`itm-${id}`).querySelector('em');
	fix = document.getElementById(`itm-${id}`).querySelector('input');
	title = document.getElementById('task-title');
	text = document.getElementById('task-text');
	fixed = document.getElementById('task-isfixed');
	repeat = document.getElementById('task-repeat');
	title.value = element.innerText;
	text.value = detail.innerText;
	((fix.getAttribute('data') == 0 )||(fix.getAttribute('data') == "0")) ? fixed.checked = false : fixed.checked = true ;
	repeat.selectedIndex = fix.value;
	btn = document.getElementsByClassName('addevent');
	btn[0].setAttribute('onclick','handleAdd(' + months + ',' + days + ',' + id + ')');
	
	const dayindex = document.getElementsByClassName(`date-${months}-${days}`)[0].getAttribute('index');
}

function handleDelete(months,days,id) {
	if (window.confirm('آیا از حذف مطمئن هستید؟') === true) {
		let title = document.getElementById(`itm-${id}`).querySelector(`span`).innerText;
		let detail = document.getElementById(`itm-${id}`).querySelector(`em`).innerText;
		let dayindex = document.getElementsByClassName(`date-${months}-${days}`)[0].getAttribute('index');
		let el = document.getElementById(`itm-${id}`);
		counter = document.getElementsByClassName('task-count')[0];
		const payload = {
			id :id
		};
		fetch(`${domain}delevents.php`, {
			method : 'POST',
			headers: [
				["Content-Type", "application/json"],
				["Content-Type", "text/plain"]
			],
			credentials: "include",
			body: JSON.stringify(payload)
		})
		.then(res => { 
			if (res.status === 200) {
				return res.json().then(data => ({ ok: true, data }));
			} else if (res.status === 404) {
				return res.json().then(data => ({ ok: false, data }));
			}
		})
		.then(result => {
			if (result.ok) {
				let i = 0;
				temp = calendarObject[months-1][dayindex-1][6];
				for(let i = 0;i < temp.length;i++){
					t = calendarObject[months-1][dayindex-1][6][i].split(':');
					if ( `${t[0]}:${t[1]}:${t[2]}` === `${title}:${detail}:${id}`) {
						calendarObject[months-1][dayindex-1][6].splice(i, 1);
						i = temp.length;
					}
				}
				el.remove();
				if (calendarObject[months-1][dayindex-1][6].length < 1)
					document.getElementsByClassName(`date-${months}-${days}`)[0].children[3].remove();
				c = counter.innerText.convertDigits('en');
				c = c - 1;
				counter.innerText = c.toString().convertDigits('fa');
			}
		})
		.catch(err => console.error ( "خطا", err ));
	}
}

function handleDelAll(mnth,days) {
	if(window.confirm('آیا از حذف مطمئن هستید؟') == true) {
		const modal = document.getElementById('tasksItems');
		modal.innerHTML = '';
		calendarObject.splice(mnth-1, 1);
		payload = {
		month: mnth,
		day: days
		};
		fetch(`${domain}deleteevents.php`, {
			method: 'POST',
			headers: {"Content-Type" : "application/json"},
			body: JSON.stringify(payload)
		})
		.then(res => res.text())
		.then(data => {	/*console.log('ok');*/ 	})
		.catch(err => console.error ( "خطا", err ))
			z = "0";
			document.getElementsByClassName('task-count')[0].innerText = z.convertDigits('fa');
			document.getElementsByClassName(`date-${mnth}-${days}`)[0].children[3].remove();
	}
}

function handleIgnore(id,months,days,event) {
	const notif_ul = document.getElementById('ntf_u');
	if (window.confirm('هشدار رویداد مورد نظر حذف شود؟') == true) {
		let dayindex = document.getElementsByClassName(`date-${months}-${days}`)[0].getAttribute('index');
		const payload = {
			id: id
		};
		fetch(`${domain}ignore.php`, {
			method : 'POST',
			headers: [
				["Content-Type", "application/json"],
				["Content-Type", "text/plain"]
			],
			credentials: "include",
			body : JSON.stringify(payload)
		})
		.then(res => res.text())
		.then(data => {
			if (data == "ok"){
				if (document.getElementById('modal').classList.contains('is-open'))
					handleModalClose();
				temp = calendarObject[months-1][dayindex-1][6];
				for(let i = 0;i < temp.length;i++){
					t = calendarObject[months-1][dayindex-1][6][i].split(':');
					if ( `${t[2]}` === `${id}`) {
						t[4] = "0";
						calendarObject[months-1][dayindex-1][6][i]=`${t[0]}:${t[1]}:${t[2]}:${t[3]}:${t[4]}`;
						i = temp.length;
					}
				}
				//svg.a.div.li
				event.parentNode.parentNode.parentNode.remove();
				if (notif_ul.getElementsByTagName("li").length < 1){
					notif_ul.innerHTML += '<li><h6 class="content text-end">لیست خالی است</h6></li>';
					document.getElementsByClassName("reddot")[0].remove();
				}
			}
		})
		.catch(err => alert(err));

	}
}

//show event description
function showText(id){
	var tbdy = document.getElementById('tasksItems');
	var arr = tbdy.getElementsByTagName('em');
	x = document.getElementById(`itm-${id}`).querySelector('em');
	if (x.classList.contains ('display-none')) {
		for( i = 0; i < arr.length; i++) {
			if (!arr[i].classList.contains('display-none'))
					arr[i].classList.add('display-none');
		}
		x.classList.remove('display-none');
	} else {
		x.classList.add('display-none');
	}
}

//build year drpdown items
function build_year(){
    data = '';
	if ((jyear >= 1350) && (jyear <= 1450)) {
		for (i = 1350;i < jyear;i++)
			data += "<a class='btn ms-2' onclick='selectYear(this)' href='javascript:void(0);'>" + String(i) + "</a>";
		
		data += "<a class='btn ms-2 active active-season' onclick='selectYear(this)' selected href='javascript:void(0);'>" + String(jyear) + "</a>";
		
		for (i = jyear + 1;i <= 1450;i++)
			data += "<a class='btn ms-2' onclick='selectYear(this)' href='javascript:void(0);'>" + String(i) + "</a>";
	} else {
		data += "<a class='btn ms-2 active active-season' onclick='selectYear(this)' selected href='javascript:void(0);'>" + String(jyear) + "</a>";
		
		for (i = 1350;i < 1450;i++)
			data += "<a class='btn ms-2' onclick='selectYear(this)' href='javascript:void(0);'>" + String(i) + "</a>";
	}
	document.getElementById('yearselector').innerHTML = data.convertDigits('fa');
	scrollToCenter();
}
//scroll to selected year btn in list
function scrollToCenter() {
	element = document.querySelector('#yearselector .active');
    element.scrollIntoView({
        behavior : 'smooth',
        inline : 'center',
        block : 'nearest'
    });
  }

//goto selected year
function selectYear(selectedYear){
	const yearUrl = selectedYear.text;
	(yearUrl) ? window.location = "index.php?year=" + yearUrl.convertDigits('en')
			  : window.location = "index.php";
}

function holidayform(){
	fetch(`${domain}addholidayform.php`, {
		method : 'GET'
	})
	.then(res => res.text())
	.then(data => {
		if (data){
			const main = document.getElementById('main');
			const modal = document.getElementById('modal');
			modal.classList.add('is-open');
			main.classList.add('modal-is-open');
			l = document.getElementsByTagName('body')[0];
			modal.innerHTML = '';
			modal.insertAdjacentHTML('afterbegin',data);
		} else alert(data);
	})
	.catch(err => console.error ( "خطا", err ));
}

function addholiday(){
	myform = new FormData(document.getElementById('task-form'));
	fetch(`${domain}addholiday.php`, {
		method : 'POST',
		body : myform
	})
	.then(res => { if (res.status === 200) { return res.json().then(data => ({ ok: true, data })); }
					else if (res.status === 404) { return res.json().then(data => ({ ok: false, data })); }
	})
	.then(result => { (result.ok) ? handleModalClose() : alert(result); })
	.catch(err => alert(err));
}

function holidaylist(type) {
	fetch(`${domain}holidaylist.php?type=${type}`, {
		method : 'GET'
	})
	.then(res => res.text())
	.then(data => {
		if (data) {
			const main = document.getElementById('main');
			const modal = document.getElementById('modal');
			modal.classList.add('is-open');
			main.classList.add('modal-is-open');
			l = document.getElementsByTagName('body')[0];
			modal.innerHTML = '';
			modal.insertAdjacentHTML('afterbegin',data);
		} else alert(data);
	})
	.catch(err => alert (err));
}

function delholiday(id,type) {
	if (window.confirm('تایید کنید') == true){
		const payload = {
			id : id,
			type : type
		}
		fetch(`${domain}delholiday.php`, {
			method : 'POST',
			headers: [
				["Content-Type", "application/json"],
				["Content-Type", "text/plain"]
			],
			credentials: "include",
			body : JSON.stringify(payload)
		})
		.then(res =>{if (res.status === 200) { return res.json().then(data => ({ ok: true, data }));}
				else if (res.status === 404) { return res.json().then(data => ({ ok: false, data }));}
		})
		.then(result => {
			if (result.ok){
				e =  document.getElementById('holdy-' + id);
				e1 = e.getAttribute('data').split(',');
				months = Number(e1[0]); 
				day = Number(e1[1]);
				let dayindex = document.getElementsByClassName(`date-${e1[0]}-${e1[1]}`)[0].getAttribute('index');
				temp = calendarObject[months-1][dayindex-1][6];
				for(let i=  0; i < temp.length; i++){
					t = calendarObject[months-1][dayindex-1][6][i].split(':');
					if (`${t[2]}`=== `${id*2}`) {
					calendarObject[months-1][dayindex-1][6].splice(i,1);
					i = temp.length;
					}
				}
				document.getElementById('holdy-' + id).remove();
			}
		})
		.catch(err => console.error ( "خطا", err ));
	}
}

function showToast() {
	const container = document.getElementById("toast-container");
	for (let i = 0; i < notifs.length; i++) {
		const toast = document.createElement("div");
		toast.className = "toast active-season";
		toast.innerText = notifs[i][1];

		container.appendChild(toast);

		setTimeout(() => {toast.classList.add("show");}, i * 200);

		setTimeout(() => {toast.classList.remove("show");}, 3000 + (i * 200));

		setTimeout(() => {toast.remove();}, 1500 + (i * 200));
	}
}
/***************************************************** */
//ساخت لیست سالها
build_year();
window.onkeyup = function(e){
	const keyName = e.code;
	let action = null;
	
	if(keyName == "ArrowLeft"){
		action = "INCREASE";
	}else if(keyName == "ArrowRight"){
		action = "DECREASE";
	}else{
		return;
	}
	
	const activeMonthDOM = document.getElementsByClassName("active-season-cr")[0];
	const numberMonth = activeMonthDOM.getAttribute("data-num");
	
	let numberMonthFinal = 0;
	
	if(action == "INCREASE"){
		numberMonthFinal = parseInt(numberMonth) + 1;
	}else if(action == "DECREASE"){
		numberMonthFinal = parseInt(numberMonth) - 1;	
	}
	
	if(numberMonthFinal == 13){
		numberMonthFinal = 1;
	}
	if(numberMonthFinal == 0 ){
		numberMonthFinal = 12;
	}
	
	const newMonthDOM = document.getElementsByClassName("month-letter")[(numberMonthFinal-1)];
	
	const eventClick = new Event("click");
	
	newMonthDOM.dispatchEvent(eventClick);
}



